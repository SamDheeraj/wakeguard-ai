import { FaceLandmarker, FilesetResolver } from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0";

// --- Audio System (Web Audio API) ---
let audioCtx;
let oscillator;
let gainNode;
let isAlerting = false;

function initAudio() {
    try {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
    } catch (e) {
        console.error("Audio init failed:", e);
    }
}

function startSiren() {
    if (oscillator) return;
    initAudio();
    if (!audioCtx) return; // If audioCtx failed to initialize, stop here

    try {
        oscillator = audioCtx.createOscillator();
        gainNode = audioCtx.createGain();

        oscillator.type = 'sawtooth';
        oscillator.frequency.setValueAtTime(600, audioCtx.currentTime);

        const now = audioCtx.currentTime;
        oscillator.frequency.linearRampToValueAtTime(1200, now + 0.5);
        oscillator.frequency.linearRampToValueAtTime(600, now + 1.0);
        oscillator.frequency.linearRampToValueAtTime(1200, now + 1.5);
        oscillator.frequency.linearRampToValueAtTime(600, now + 2.0);

        const lfo = audioCtx.createOscillator();
        lfo.type = 'sine';
        lfo.frequency.value = 2;
        const lfoGain = audioCtx.createGain();
        lfoGain.gain.value = 300;

        lfo.connect(lfoGain);
        lfoGain.connect(oscillator.frequency);
        lfo.start();

        gainNode.gain.setValueAtTime(0.1, now);
        gainNode.gain.linearRampToValueAtTime(0.5, now + 0.1);

        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.start();

        oscillator.lfo = lfo;
    } catch (e) {
        console.error("Siren failed:", e);
    }
}

function stopSiren() {
    if (oscillator) {
        try {
            const now = audioCtx.currentTime;
            gainNode.gain.linearRampToValueAtTime(0, now + 0.1);

            setTimeout(() => {
                if (oscillator) {
                    oscillator.stop();
                    if (oscillator.lfo) oscillator.lfo.stop();
                    oscillator.disconnect();
                    oscillator = null;
                }
            }, 100);
        } catch (e) {
            console.error("Stop siren failed:", e);
        }
    }
}

// --- DOM Elements ---
const video = document.getElementById("webcam");
const canvasElement = document.getElementById("output_canvas");
const canvasCtx = canvasElement.getContext("2d");
const toggleButton = document.getElementById("toggle-cam");
const statusDot = document.getElementById("status-dot");
const statusText = document.getElementById("system-status");
const earDisplay = document.getElementById("ear-value");
const alertOverlay = document.getElementById("drowsy-alert");

let faceLandmarker;
let runningMode = "VIDEO";
let webcamRunning = false;
let lastVideoTime = -1;
let results = undefined;
let isModelLoaded = false;
let drowsyFrames = 0;

// --- Initialization ---
async function createFaceLandmarker() {
    try {
        const filesetResolver = await FilesetResolver.forVisionTasks(
            "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0/wasm"
        );
        faceLandmarker = await FaceLandmarker.createFromOptions(filesetResolver, {
            baseOptions: {
                modelAssetPath: `https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task`,
                delegate: "GPU"
            },
            outputFaceBlendshapes: true,
            runningMode,
            numFaces: 1
        });
        isModelLoaded = true;
        console.log("Model Loaded");

        // If webcam is already running, update status
        if (webcamRunning) {
            statusText.textContent = "Active Monitoring";
            statusDot.className = "status-dot active";
        }
    } catch (e) {
        console.error(e);
        statusText.textContent = "Model Error";
        statusDot.className = "status-dot error";
    }
}

createFaceLandmarker();

// --- Camera Logic ---
function hasGetUserMedia() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
}

if (hasGetUserMedia()) {
    toggleButton.addEventListener("click", (e) => {
        // Try to init audio, but don't block camera if it fails
        initAudio();
        enableCam(e);
    });
} else {
    console.warn("getUserMedia() is not supported by your browser");
}

async function enableCam(event) {
    if (webcamRunning === true) {
        webcamRunning = false;
        toggleButton.innerText = "Start Camera";
        statusText.textContent = "Standby";
        statusDot.className = "status-dot";
        video.pause();
        if (video.srcObject) { // Check if srcObject exists before trying to stop tracks
            video.srcObject.getTracks().forEach(track => track.stop());
        }
        video.srcObject = null;
        canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
        earDisplay.textContent = "--";
        clearAlert();
    } else {
        webcamRunning = true;
        toggleButton.innerText = "Stop Camera";

        // Immediate Status Update
        if (isModelLoaded) {
            statusText.textContent = "Active Monitoring";
            statusDot.className = "status-dot active";
        } else {
            statusText.textContent = "Initializing AI...";
            statusDot.className = "status-dot"; // Orange/Default
        }

        const constraints = { video: true };

        try {
            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            video.srcObject = stream;
            video.addEventListener("loadeddata", predictWebcam);
        } catch (err) {
            console.error(err);
            webcamRunning = false;
            toggleButton.innerText = "Start Camera";
            statusText.textContent = "Camera Error";
            statusDot.className = "status-dot error";
            alert("Camera access denied. Please allow camera permissions.");
        }
    }
}

async function predictWebcam() {
    canvasElement.style.width = video.videoWidth;
    canvasElement.style.height = video.videoHeight;
    canvasElement.width = video.videoWidth;
    canvasElement.height = video.videoHeight;

    let startTimeMs = performance.now();

    // Only detect if model is loaded
    if (isModelLoaded && lastVideoTime !== video.currentTime) {
        lastVideoTime = video.currentTime;
        results = faceLandmarker.detectForVideo(video, startTimeMs);

        // Ensure status reflects active state once model loads during stream
        if (statusText.textContent === "Initializing AI...") {
            statusText.textContent = "Active Monitoring";
            statusDot.className = "status-dot active";
        }
    }

    if (results && results.faceLandmarks) {
        for (const landmarks of results.faceLandmarks) {
            const ear = calculateEAR(landmarks);
            earDisplay.textContent = ear.toFixed(2);

            // Drowsiness Logic with Blink Filter
            // EAR < 0.25 means eyes are closed
            // We wait for ~30 frames (approx 1 sec) to confirm drowsiness
            if (ear < 0.25) {
                drowsyFrames++;
                if (drowsyFrames > 25) { // Threshold: 25 frames
                    triggerAlert();
                }
            } else {
                drowsyFrames = 0;
                clearAlert();
            }
        }
    }

    if (webcamRunning === true) {
        window.requestAnimationFrame(predictWebcam);
    }
}

// EAR Calculation
function calculateEAR(landmarks) {
    const leftEye = [33, 160, 158, 133, 153, 144];
    const rightEye = [362, 385, 387, 263, 373, 380];
    const leftEAR = getEyeRatio(landmarks, leftEye);
    const rightEAR = getEyeRatio(landmarks, rightEye);
    return (leftEAR + rightEAR) / 2;
}

function getEyeRatio(landmarks, indices) {
    const v1 = dist(landmarks[indices[1]], landmarks[indices[5]]);
    const v2 = dist(landmarks[indices[2]], landmarks[indices[4]]);
    const h = dist(landmarks[indices[0]], landmarks[indices[3]]);
    return (v1 + v2) / (2.0 * h);
}

function dist(p1, p2) {
    return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
}

// Alert System
function triggerAlert() {
    if (!isAlerting) {
        isAlerting = true;
        alertOverlay.classList.remove('hidden');
        startSiren();
    }
}

function clearAlert() {
    if (isAlerting) {
        isAlerting = false;
        alertOverlay.classList.add('hidden');
        stopSiren();
    }
}
