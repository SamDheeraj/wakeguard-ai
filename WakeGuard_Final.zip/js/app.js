// Navigation Logic
function showPage(pageId) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });

    // Show selected page
    document.getElementById(pageId).classList.add('active');

    // Update nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // Find the button that corresponds to this pageId and activate it
    // Note: This is a simple heuristic, assuming button text/onclick matches
    const buttons = document.querySelectorAll('.nav-btn');
    buttons.forEach(btn => {
        if (btn.getAttribute('onclick').includes(pageId)) {
            btn.classList.add('active');
        }
    });
}

// Education Page Logic
const timeSlider = document.getElementById('time-slider');
const timeDisplay = document.getElementById('time-display');
const alertnessValue = document.getElementById('alertness-value');

if (timeSlider) {
    timeSlider.addEventListener('input', (e) => {
        const val = parseInt(e.target.value);
        const ampm = val >= 12 ? 'PM' : 'AM';
        const displayVal = val % 12 || 12;
        timeDisplay.textContent = `${displayVal}:00 ${ampm}`;

        // Simple circadian logic
        if (val >= 23 || val <= 5) {
            alertnessValue.textContent = "Low";
            alertnessValue.className = "metric-value bad";
        } else if (val >= 13 && val <= 15) {
            alertnessValue.textContent = "Moderate";
            alertnessValue.className = "metric-value warn";
        } else {
            alertnessValue.textContent = "High";
            alertnessValue.className = "metric-value good";
        }
    });
}
